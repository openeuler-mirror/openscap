version=1.3.2
previous_version=1.3.1
latest_fedora=31
latest_rhel=8

version_major_minor="${version%.*}"
