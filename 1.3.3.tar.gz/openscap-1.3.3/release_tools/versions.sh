version=1.3.3
previous_version=1.3.2
latest_fedora=32
latest_rhel=8

version_major_minor="${version%.*}"
