#!/bin/bash

exit $XCCDF_RESULT_PASS
