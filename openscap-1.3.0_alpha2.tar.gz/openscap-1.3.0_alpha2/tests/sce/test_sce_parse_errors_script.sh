#!/bin/sh

# This is dummy script file. Only important part is here "shebang"
