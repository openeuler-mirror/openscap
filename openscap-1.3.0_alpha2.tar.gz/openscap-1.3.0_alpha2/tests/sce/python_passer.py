#!/usr/bin/python3

import os, sys

sys.exit(int(os.environ["XCCDF_RESULT_PASS"]))

