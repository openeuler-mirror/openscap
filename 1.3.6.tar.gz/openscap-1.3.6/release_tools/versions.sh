version=1.3.6
previous_version=1.3.5

version_major_minor="${version%.*}"
