version=1.3.7
previous_version=1.3.6

version_major_minor="${version%.*}"
