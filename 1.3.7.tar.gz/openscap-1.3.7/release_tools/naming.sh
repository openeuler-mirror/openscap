declare -A name_mapping

# Put duplicate author entries here in a form
# name_mapping['<duplicate name>']='<canonical name>', e.g.
# Keep the assignments lexicographicaly sorted by the canonical name and then by the duplicate name.

# If you want to remove a name completely from the deduplicated listing, do e.g.
# name_mapping['root@localhost']=

name_mapping['Martin Preisler <martin@preisler.me>']='Martin Preisler <mpreisle@redhat.com>'
name_mapping['Matěj Týč <matej.tyc@gmail.com>']='Matěj Týč <matyc@redhat.com>'
