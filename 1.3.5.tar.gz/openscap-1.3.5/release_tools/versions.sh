version=1.3.5
previous_version=1.3.4

version_major_minor="${version%.*}"
